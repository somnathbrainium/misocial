import Header_afterlogin from "../../Layouts/Header_afterlogin";

export default function PrivacyBanner_B() {
    return (
        <div className="signupnext-banner">
            <div className="banner-container">
                <Header_afterlogin />
            </div>
        </div>
    )
}