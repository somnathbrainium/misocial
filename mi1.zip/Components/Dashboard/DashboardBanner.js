
import Header_B from '../../Layouts/Header_B';

export default function DashboardBanner() {
    return (
        <div className="dashboardbanner">

            <div className="banner-container">
                <Header_B />
            </div>
        </div>
    )
}