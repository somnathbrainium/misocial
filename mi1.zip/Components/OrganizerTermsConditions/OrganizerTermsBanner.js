import Header_C from "../../Layouts/Header_C";

export default function OrganizerTermsBanner() {
    return (
        <div className="signupnext-banner">
            <div className="banner-container">
                <Header_C />
            </div>
        </div>
    )
}