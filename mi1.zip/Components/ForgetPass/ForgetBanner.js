
import Header from '../../Layouts/Header';
export default function ForgetBanner() {
    return (
        <div className="forgetBanner">
            <div className="banner-container">
                <Header />
            </div>
        </div>
    )
}