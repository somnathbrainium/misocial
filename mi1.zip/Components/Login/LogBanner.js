import Header from "../../Layouts/Header";
export default function LogBanner() {
    return (
        <div className="log-banner">
            <div className="banner-container">
                <Header />
            </div>
        </div>
    )
}