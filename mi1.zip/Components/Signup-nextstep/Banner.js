import Header from "../../Layouts/Header";

export default function NextStepBanner() {
    return (
        <div className="signupnext-banner">
            <div className="banner-container">
                <Header />
            </div>
        </div>
    )
}