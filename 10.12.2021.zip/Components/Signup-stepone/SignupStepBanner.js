import Header from "../../Layouts/Header";

export default function SignupOnebanner() {

    return (
        <div className="signup-one-banner">
            <div className="banner-container">
                <Header />
           </div>
        </div>
    )
}