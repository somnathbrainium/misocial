
import Header_C from '../../Layouts/Header_C';

export default function DashboardBanner() {
    return (
        <div className="dashboardbanner">

            <div className="banner-container">
                <Header_C />
            </div>
        </div>
    )
}