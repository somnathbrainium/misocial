
import Header_afterlogin from '../../Layouts/Header_afterlogin';

export default function DashboardBanner() {
    return (
        <div className="dashboardbanner">

            <div className="banner-container">
                <Header_afterlogin />
            </div>
        </div>
    )
}