import EventHeader_B from "../../Layouts/EventHeader_B";

export default function EventBanner_C() {
    return (
        <div className="event-banner">
            <div className="banner-container">
                <EventHeader_B />
            </div>
        </div>
    )
}