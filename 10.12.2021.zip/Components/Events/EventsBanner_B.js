import EventHeader_afterlogin from "../../Layouts/EventHeader_afterlogin";

export default function EventsBanner_B() {
    return (
        <div className="event-banner">
            <div className="banner-container">
                <EventHeader_afterlogin />
            </div>
        </div>
    )
}